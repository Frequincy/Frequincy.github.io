﻿"use strict";

// defines scope
{
    let opts = {
        title: "This is third controller",
        text: "Third Index",
        icon: "Success",

    };

    Swal.fire(opts);
}





