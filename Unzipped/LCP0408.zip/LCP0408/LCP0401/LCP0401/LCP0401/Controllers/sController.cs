﻿using Microsoft.AspNetCore.Mvc;

namespace LCP0401.Controllers
{
    public class sController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public string getStr()
        {
            return "Second Controller";
        }





    }
}
