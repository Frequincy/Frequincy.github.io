﻿using Microsoft.AspNetCore.Mvc;

namespace LCP0401.Controllers
{
    public class ThirdController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
