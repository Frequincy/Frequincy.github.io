﻿using LCP0401.Data;
using Microsoft.AspNetCore.Mvc;

namespace LCP0401.Controllers
{
    public class HomeController : Controller
    {
        StudentDB db = new StudentDB();



        public IActionResult Index()
        {
            return View();
        }

        public IActionResult getP()
        {
            return View();
        }

        public IActionResult getP2()
        {
            return View();
        }

        public int getI()
        {
            return 20;
        }

        public JsonResult GD()
        {
            return Json(db.Students);
        }

        public JsonResult Gd2()
        {
            var r = db.Students.First();
            return Json(r);
        }
    }
}
