document.querySelector("#div1").style.backgroundColor = "red";
document.querySelector("#img1").style.heaight = "200px";